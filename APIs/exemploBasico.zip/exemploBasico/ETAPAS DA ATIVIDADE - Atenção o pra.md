#### ETAPAS DA ATIVIDADE - Atenção o prazo de entrega é hoje



1. Criar a conta no Infinity Free
   
2. Criar um domínio a sua escolha
   
3. Acessar a conta do infinity Free
   
4. Acessar o Painel de Controle, Acessar o menu do MYSQL e criar a base de dados
   
5. Montar a tabela no PHPMyadmin que está no arquivo de conexão da base de dados
   
6. Fazer o upload do exemplo básico que esta no GIT (https://github.com/paulopta/pbr-lab-DAD-2025) da turma para o Infinity free para a pasta HTDOCS do servidor.



5\. Atualizar o arquivo do Banco de Dados informando os valores corretos, que foram informados na aba de criação da base de dados



6\. Acesse o PHPMyAdmin, clique na base de dados, cole o sql que está no arquivo conexa\_bd na aba de SQL do PHPMyadmin e execute para criar a tarefa



7\. Testar e responder a atividade no GIT da Tuma

&nbsp;

