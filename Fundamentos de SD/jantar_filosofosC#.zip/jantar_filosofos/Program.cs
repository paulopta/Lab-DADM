﻿using System;
using System.Threading;

namespace AtividadeDeadlock
{
    class Program
    {
        // Recursos compartilhados
        private static readonly object RecursoA = new object();
        private static readonly object RecursoB = new object();

        static void Main(string[] args)
        {
            bool executando = true;

            while (executando)
            {
                Console.Clear();
                Console.WriteLine("==================================================");
                Console.WriteLine("    LABORATÓRIO DE DEADLOCK - CONDIÇÕES DE COFFMAN");
                Console.WriteLine("==================================================");
                Console.WriteLine("1. Simular DEADLOCK (Todas as 4 condições ativas)");
                Console.WriteLine("2. Quebrar ESPERA CIRCULAR (Ordenação Global de Recursos)");
                Console.WriteLine("3. Quebrar POSSE E ESPERA (Tentar/Liberar com Timeout)");
                Console.WriteLine("4. Explicar as 4 Condições de Coffman");
                Console.WriteLine("0. Sair");
                Console.WriteLine("==================================================");
                Console.Write("Escolha uma opção: ");

                string opcao = Console.ReadLine();
                Console.WriteLine();

                switch (opcao)
                {
                    case "1":
                        SimularDeadlock();
                        Pausar();
                        break;
                    case "2":
                        ResolverPorOrdenacao();
                        Pausar();
                        break;
                    case "3":
                        ResolverPorTimeout();
                        Pausar();
                        break;
                    case "4":
                        ExplicarCondicoes();
                        Pausar();
                        break;
                    case "0":
                        executando = false;
                        break;
                    default:
                        Console.WriteLine("Opção inválida!");
                        Pausar();
                        break;
                }
            }
        }

        #region Opção 1: Simulação do Deadlock
        static void SimularDeadlock()
        {
            Console.WriteLine("[INICIANDO SIMULAÇÃO DE DEADLOCK]");
            Console.WriteLine("Pressione 'Ctrl+C' ou feche a janela caso o programa trave indefinidamente.\n");

            Thread thread1 = new Thread(() =>
            {
                lock (RecursoA)
                {
                    Console.WriteLine("-> Thread 1: Adquiriu Recurso A (Posse e Espera)");
                    Thread.Sleep(500); // Força a troca de contexto

                    Console.WriteLine("   Thread 1: Agurdando Recurso B...");
                    lock (RecursoB)
                    {
                        Console.WriteLine("SUCESSO: Thread 1 adquiriu Recurso B!");
                    }
                }
            });

            Thread thread2 = new Thread(() =>
            {
                lock (RecursoB)
                {
                    Console.WriteLine("-> Thread 2: Adquiriu Recurso B (Posse e Espera)");
                    Thread.Sleep(500); // Força a troca de contexto

                    Console.WriteLine("   Thread 2: Aguardando Recurso A...");
                    lock (RecursoA)
                    {
                        Console.WriteLine("SUCESSO: Thread 2 adquiriu Recurso A!");
                    }
                }
            });

            thread1.Start();
            thread2.Start();

            // Espera até 3 segundos pelas threads. Se não terminarem, houve impasse.
            if (!thread1.Join(3000) || !thread2.Join(3000))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n[IMPASSE DETECTADO!] As threads ficaram presas em Deadlock.");
                Console.ResetColor();
            }
        }
        #endregion

        #region Opção 2: Solução Quebrando a Espera Circular
        static void ResolverPorOrdenacao()
        {
            Console.WriteLine("[SOLUÇÃO: QUEBRANDO A ESPERA CIRCULAR]");
            Console.WriteLine("Ambas as Threads solicitam os recursos estritamente na mesma ordem (A -> B).\n");

            Thread thread1 = new Thread(() =>
            {
                lock (RecursoA)
                {
                    Console.WriteLine("-> Thread 1: Adquiriu Recurso A");
                    Thread.Sleep(200);

                    lock (RecursoB)
                    {
                        Console.WriteLine("-> Thread 1: Adquiriu Recurso B e concluiu a tarefa!");
                    }
                }
            });

            Thread thread2 = new Thread(() =>
            {
                // Ordenação mantida: RecursoA primeiro, depois RecursoB
                lock (RecursoA)
                {
                    Console.WriteLine("-> Thread 2: Adquiriu Recurso A");
                    Thread.Sleep(200);

                    lock (RecursoB)
                    {
                        Console.WriteLine("-> Thread 2: Adquiriu Recurso B e concluiu a tarefa!");
                    }
                }
            });

            thread1.Start();
            thread2.Start();

            thread1.Join();
            thread2.Join();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n[SUCESSO] Ambas as threads executaram sem travar!");
            Console.ResetColor();
        }
        #endregion

        #region Opção 3: Solução Quebrando a Posse e Espera
        static void ResolverPorTimeout()
        {
            Console.WriteLine("[SOLUÇÃO: QUEBRANDO A POSSE E ESPERA (TIMEOUT)]");
            Console.WriteLine("Caso a thread não consiga o 2º recurso, ela solta o 1º recurso e tenta novamente.\n");

            Thread thread1 = new Thread(() => ExecutarComTimeout("Thread 1", RecursoA, RecursoB));
            Thread thread2 = new Thread(() => ExecutarComTimeout("Thread 2", RecursoB, RecursoA));

            thread1.Start();
            thread2.Start();

            thread1.Join();
            thread2.Join();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n[SUCESSO] As threads desistiram de segurar os recursos ao falhar e executaram com sucesso!");
            Console.ResetColor();
        }

        static void ExecutarComTimeout(string nomeThread, object primeiroRecurso, object segundoRecurso)
        {
            bool obteveAmbos = false;

            while (!obteveAmbos)
            {
                if (Monitor.TryEnter(primeiroRecurso, 1000))
                {
                    try
                    {
                        Console.WriteLine($"-> {nomeThread}: Adquiriu 1º recurso.");
                        Thread.Sleep(200);

                        // Tenta adquirir o segundo recurso com tempo limite
                        if (Monitor.TryEnter(segundoRecurso, 500))
                        {
                            try
                            {
                                Console.WriteLine($"-> {nomeThread}: Adquiriu 2º recurso e concluiu a tarefa!");
                                obteveAmbos = true;
                            }
                            finally
                            {
                                Monitor.Exit(segundoRecurso);
                            }
                        }
                        else
                        {
                            Console.WriteLine($"   {nomeThread}: Falha ao obter 2º recurso. Liberando 1º recurso para tentar novamente...");
                        }
                    }
                    finally
                    {
                        Monitor.Exit(primeiroRecurso);
                    }
                }

                // Aguarda um tempo aleatório antes de tentar novamente para evitar starvation
                if (!obteveAmbos)
                {
                    Thread.Sleep(new Random().Next(100, 300));
                }
            }
        }
        #endregion

        #region Opção 4: Explicação Teórica
        static void ExplicarCondicoes()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("--- AS 4 CONDIÇÕES NECESSÁRIAS DE COFFMAN PARA DEADLOCK ---\n");
            Console.WriteLine("1. Exclusão Mútua:");
            Console.WriteLine("   Um recurso só pode estar alocado para um processo por vez (no código: uso de 'lock').\n");
            Console.WriteLine("2. Posse e Espera (Hold and Wait):");
            Console.WriteLine("   Um processo retém um recurso enquanto aguarda por outro recurso (no código: lock interno).\n");
            Console.WriteLine("3. Não Preempção:");
            Console.WriteLine("   Recursos não podem ser tomados à força; são liberados apenas voluntariamente.\n");
            Console.WriteLine("4. Espera Circular:");
            Console.WriteLine("   Existe uma cadeia circular de processos onde cada um espera pelo recurso do próximo.\n");
            Console.ResetColor();
        }
        #endregion

        static void Pausar()
        {
            Console.WriteLine("\nPressione qualquer tecla para voltar ao menu...");
            Console.ReadKey();
        }
    }
}